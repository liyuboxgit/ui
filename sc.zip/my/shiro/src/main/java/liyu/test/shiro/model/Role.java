package liyu.test.shiro.model;

public class Role {

	public String getRole() {
		// TODO Auto-generated method stub
		return null;
	}

}
