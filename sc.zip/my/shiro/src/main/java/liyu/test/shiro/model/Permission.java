package liyu.test.shiro.model;

public class Permission {

	public String getPermission() {
		// TODO Auto-generated method stub
		return null;
	}

}
