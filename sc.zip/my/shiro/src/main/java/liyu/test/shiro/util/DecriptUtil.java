package liyu.test.shiro.util;

public class DecriptUtil {
	/*<property name="hashAlgorithmName" value="md5" />
    <property name="hashIterations" value="2" />*/
	
	/**
	 * 
	 * @Title: MD5 
	 * @Description: 这里为简单起见，没有加密
	 * @param password
	 * @return
	 * @return: Object
	 */
	public static Object MD5(Object password) {
		return password;
	}

}
