package liyu.test.mybatis.mapper;
import liyu.test.mybatis.model.BaoGuanDan;
public interface BaoGuanDanMapper extends BaseMapper<BaoGuanDan>{
}