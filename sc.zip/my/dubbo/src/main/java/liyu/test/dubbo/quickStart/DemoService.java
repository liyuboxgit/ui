package liyu.test.dubbo.quickStart;

public interface DemoService {
    String sayHello(String name);
}