package liyu.test.springboot.service;

public class BaseService {

}
