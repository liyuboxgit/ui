package liyu.test.security.entity.po;

import liyu.test.security.entity.Position;

public class PositionPo extends Position{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
