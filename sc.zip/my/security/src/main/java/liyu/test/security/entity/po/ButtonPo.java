package liyu.test.security.entity.po;

import liyu.test.security.entity.Button;

public class ButtonPo extends Button{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
