package liyu.test.security.entity.po;

import liyu.test.security.entity.Module;

public class ModulePo extends Module{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
