package liyu.test.security.entity.po;

import liyu.test.security.entity.User;;

public class UserPo extends User {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
