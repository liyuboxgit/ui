package liyu.test.framework.mvc;

public class BaseEntity{
	
}
