package security;

public class NativeCommond {

	public static void main(String[] args) {
		///本地命令
		/*try { 
             ProcessBuilder proc = new ProcessBuilder("notepad.exe", "logs.log"); 
             Process start = proc.start();
             
             Thread.sleep(5000);
             
             start.destroyForcibly();
	     } catch (Exception e) { 
	    	 System.out.println("Error executing notepad."); 
	     } */
		
	}

}
